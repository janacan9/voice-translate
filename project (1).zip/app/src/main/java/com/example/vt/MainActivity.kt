package com.example.vt

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        box.addView(TextView(this).apply {
            text = "Голосовой перевод EN→RU\n\n1. Нажми «Запустить» и дай разрешения (поверх окон, запись звука). После каждого разрешения нажми «Запустить» снова.\n2. Разреши захват экрана.\n3. Открой Instagram и нажми кнопку сбоку.\n\nГромкость «будильника» должна быть выше нуля: перевод звучит через неё."
            textSize = 16f
        })
        box.addView(Button(this).apply { text = "Запустить"; setOnClickListener { start() } })
        setContentView(box)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, TranslateService::class.java).putExtra("code", resultCode).putExtra("data", data))
            moveTaskToBack(true)
        }
    }
}
