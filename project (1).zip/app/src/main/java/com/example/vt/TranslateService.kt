package com.example.vt

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.URL
import java.util.Locale
import java.util.zip.ZipInputStream

// Громкость оригинала во время перевода (0 = тишина). Если звук не захватывается, попробуй 1.
const val MUTE_LEVEL = 0

class TranslateService : Service() {
    private var proj: MediaProjection? = null
    private var rec: AudioRecord? = null
    private var tts: TextToSpeech? = null
    private var model: Model? = null
    private var translator: Translator? = null
    private var wm: WindowManager? = null
    private var btn: TextView? = null
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var ready = false
    @Volatile private var active = false
    private var savedVol = 5

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vt", "Перевод", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "vt").setContentTitle("Голосовой перевод работает")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val code = i?.getIntExtra("code", 0) ?: 0
        val data = i?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        proj = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(code, data)
        proj?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, ui)
        addButton()
        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ru")
                tts?.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            }
        }
        Thread { prepare() }.start()
        return START_NOT_STICKY
    }

    private fun addButton() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = TextView(this).apply {
            text = "…"; textSize = 14f; setTextColor(Color.WHITE)
            setBackgroundColor(0xCC000000.toInt()); setPadding(24, 32, 24, 32)
            setOnClickListener { toggle() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        wm?.addView(b, lp)
        btn = b
    }

    private fun status(s: String) { ui.post { btn?.text = s } }

    private fun prepare() {
        try {
            status("Модель…")
            val dir = File(filesDir, "model")
            if (!File(dir, "am").exists()) {
                try { download(dir) } catch (e: Exception) { dir.deleteRecursively(); throw e }
            }
            model = Model(dir.absolutePath)
            status("Перевод…")
            val t = Translation.getClient(TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.RUSSIAN).build())
            translator = t
            Tasks.await(t.downloadModelIfNeeded(DownloadConditions.Builder().build()))
            ready = true
            status("ВЫКЛ")
        } catch (e: Exception) {
            status("Ошибка: ${e.message}")
        }
    }

    private fun download(dir: File) {
        val c = URL("https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip").openConnection()
        ZipInputStream(c.getInputStream().buffered()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val name = e.name.substringAfter('/')
                if (name.isNotEmpty()) {
                    val f = File(dir, name)
                    if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { z.copyTo(it) } }
                }
                e = z.nextEntry
            }
        }
    }

    private fun toggle() {
        if (!ready) return
        if (active) stopCapture() else startCapture()
    }

    private fun startCapture() {
        val am = getSystemService(AudioManager::class.java)
        savedVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val cfg = AudioPlaybackCaptureConfiguration.Builder(proj!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
        val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(16000).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
        val r = AudioRecord.Builder().setAudioPlaybackCaptureConfig(cfg).setAudioFormat(fmt)
            .setBufferSizeInBytes(32000).build()
        rec = r
        active = true
        r.startRecording()
        am.setStreamVolume(AudioManager.STREAM_MUSIC, MUTE_LEVEL, 0)
        status("ВКЛ")
        Thread { loop(r) }.start()
    }

    private fun loop(r: AudioRecord) {
        val rc = Recognizer(model!!, 16000f)
        val buf = ShortArray(4000)
        while (active) {
            val n = r.read(buf, 0, buf.size)
            if (n > 0 && rc.acceptWaveForm(buf, n)) {
                val text = JSONObject(rc.result).optString("text")
                if (text.isNotBlank()) {
                    translator?.translate(text)?.addOnSuccessListener { ru ->
                        tts?.speak(ru, TextToSpeech.QUEUE_ADD, null, null)
                    }
                }
            }
        }
        rc.close()
    }

    private fun stopCapture() {
        active = false
        try { rec?.stop(); rec?.release() } catch (e: Exception) {}
        rec = null
        tts?.stop()
        getSystemService(AudioManager::class.java).setStreamVolume(AudioManager.STREAM_MUSIC, savedVol, 0)
        status("ВЫКЛ")
    }

    override fun onDestroy() {
        if (active) stopCapture()
        try { btn?.let { wm?.removeView(it) } } catch (e: Exception) {}
        proj?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
